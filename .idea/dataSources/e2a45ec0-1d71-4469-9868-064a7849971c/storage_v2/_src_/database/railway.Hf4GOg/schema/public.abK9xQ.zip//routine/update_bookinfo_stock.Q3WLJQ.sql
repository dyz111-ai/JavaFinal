create function update_bookinfo_stock() returns trigger
    language plpgsql
as
$$
BEGIN
    -- 处理 INSERT 操作：更新新插入记录的 ISBN 库存
    IF (TG_OP = 'INSERT') THEN
        UPDATE public.bookinfo
        SET stock = (
            SELECT COUNT(*)
            FROM public.book
            WHERE isbn = NEW.isbn
        )
        WHERE isbn = NEW.isbn;
        RETURN NEW;
    END IF;

    -- 处理 DELETE 操作：更新被删除记录的 ISBN 库存
    IF (TG_OP = 'DELETE') THEN
        UPDATE public.bookinfo
        SET stock = (
            SELECT COUNT(*)
            FROM public.book
            WHERE isbn = OLD.isbn
        )
        WHERE isbn = OLD.isbn;
        RETURN OLD;
    END IF;

    -- 处理 UPDATE 操作：如果 ISBN 改变，需要更新旧 ISBN 和新 ISBN 的库存
    IF (TG_OP = 'UPDATE') THEN
        -- 更新新 ISBN 的库存
        UPDATE public.bookinfo
        SET stock = (
            SELECT COUNT(*)
            FROM public.book
            WHERE isbn = NEW.isbn
        )
        WHERE isbn = NEW.isbn;

        -- 如果 ISBN 改变了，还需要更新旧 ISBN 的库存
        IF (OLD.isbn IS DISTINCT FROM NEW.isbn) THEN
            UPDATE public.bookinfo
            SET stock = (
                SELECT COUNT(*)
                FROM public.book
                WHERE isbn = OLD.isbn
            )
            WHERE isbn = OLD.isbn;
        END IF;

        RETURN NEW;
    END IF;

    RETURN NULL;
END;
$$;

alter function update_bookinfo_stock() owner to postgres;

